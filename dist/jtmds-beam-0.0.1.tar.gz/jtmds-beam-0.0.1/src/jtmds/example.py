def add_one(number):
    return number + 1


def hello_world():
    return "Hello World"